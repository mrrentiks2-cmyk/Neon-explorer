package app.neonexplorer;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Tiny HTTP server: open phone files from a computer browser on the same Wi-Fi. */
class WebShare {
    interface Host {
        List<File> roots();
        void emit(JSONObject o);
    }

    final Host host;
    ServerSocket ss;
    ExecutorService pool;
    volatile boolean running;
    String token = "", page = "", url = "";
    volatile boolean upload = true;
    int port;

    WebShare(Host h) { host = h; }

    synchronized JSONObject start(String html, boolean allowUpload) {
        JSONObject o = new JSONObject();
        try {
            upload = allowUpload;
            if (!running) {
                String abc = "abcdefghjkmnpqrstuvwxyz23456789";
                SecureRandom r = new SecureRandom();
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < 6; i++) sb.append(abc.charAt(r.nextInt(abc.length())));
                token = sb.toString();
                IOException last = null;
                for (int p = 8080; p < 8100 && ss == null; p++) {
                    try { ss = new ServerSocket(p, 50); port = p; } catch (IOException e) { last = e; }
                }
                if (ss == null) throw last != null ? last : new IOException("Нет свободного порта");
                page = html.replace("__TOKEN__", token);
                running = true;
                pool = Executors.newFixedThreadPool(8);
                Thread t = new Thread(this::acceptLoop, "webshare");
                t.setDaemon(true);
                t.start();
            }
            String ip = ip();
            url = ip == null ? "" : "http://" + ip + ":" + port + "/" + token + "/";
            o.put("running", true); o.put("url", url); o.put("ip", ip == null ? "" : ip); o.put("upload", upload);
            if (ip == null) o.put("warn", "Телефон не подключён к Wi-Fi. Подключитесь к той же сети, что и компьютер, или включите точку доступа.");
        } catch (Exception e) { try { o.put("running", false); o.put("error", e.getMessage()); } catch (Exception ignored) { } }
        return o;
    }

    synchronized void stop() {
        running = false;
        try { if (ss != null) ss.close(); } catch (IOException ignored) { }
        ss = null;
        if (pool != null) pool.shutdownNow();
        pool = null;
    }

    JSONObject state() {
        JSONObject o = new JSONObject();
        try { o.put("running", running); o.put("url", url); o.put("upload", upload); } catch (Exception ignored) { }
        return o;
    }

    static String ip() {
        String best = null;
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                String n = ni.getName().toLowerCase(Locale.ROOT);
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress()) continue;
                    String s = a.getHostAddress();
                    if (n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("eth")) return s;
                    if (best == null && a.isSiteLocalAddress() && !n.startsWith("rmnet") && !n.startsWith("ccmni")) best = s;
                }
            }
        } catch (Exception ignored) { }
        return best;
    }

    void acceptLoop() {
        while (running) {
            try {
                Socket s = ss.accept();
                ExecutorService p = pool;
                if (p == null) { s.close(); break; }
                p.execute(() -> { try { handle(s); } catch (Exception ignored) { } finally { try { s.close(); } catch (IOException ignored) { } } });
            } catch (IOException e) { if (!running) break; }
        }
    }

    static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) >= 0) { if (c == '\n') break; if (c != '\r') bo.write(c); if (bo.size() > 16384) throw new IOException("line"); }
        if (c < 0 && bo.size() == 0) return null;
        return bo.toString("UTF-8");
    }

    static Map<String, String> query(String q) {
        Map<String, String> m = new HashMap<>();
        if (q == null) return m;
        for (String kv : q.split("&")) {
            int i = kv.indexOf('=');
            try {
                if (i > 0) m.put(URLDecoder.decode(kv.substring(0, i), "UTF-8"), URLDecoder.decode(kv.substring(i + 1), "UTF-8"));
                else if (!kv.isEmpty()) m.put(URLDecoder.decode(kv, "UTF-8"), "");
            } catch (Exception ignored) { }
        }
        return m;
    }

    static void head(OutputStream out, int code, String reason, String mime, long len, String extra) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("HTTP/1.1 ").append(code).append(' ').append(reason).append("\r\n");
        if (mime != null) sb.append("Content-Type: ").append(mime).append("\r\n");
        if (len >= 0) sb.append("Content-Length: ").append(len).append("\r\n");
        sb.append("Connection: close\r\nCache-Control: no-store\r\n");
        if (extra != null) sb.append(extra);
        sb.append("\r\n");
        out.write(sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    static void text(OutputStream out, int code, String reason, String mime, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        head(out, code, reason, mime + "; charset=utf-8", b.length, null);
        out.write(b);
    }

    boolean inRoots(File f) {
        for (File r : host.roots()) if (Util.isInside(f, r)) return true;
        return false;
    }

    void handle(Socket s) throws Exception {
        s.setSoTimeout(60000);
        InputStream in = new BufferedInputStream(s.getInputStream(), 1 << 16);
        OutputStream out = new BufferedOutputStream(s.getOutputStream(), 1 << 16);
        try {
            String line = readLine(in);
            if (line == null) return;
            String[] rq = line.split(" ");
            if (rq.length < 2) return;
            String method = rq[0], target = rq[1];
            Map<String, String> hdr = new HashMap<>();
            String h;
            while ((h = readLine(in)) != null && !h.isEmpty()) { int i = h.indexOf(':'); if (i > 0) hdr.put(h.substring(0, i).trim().toLowerCase(Locale.ROOT), h.substring(i + 1).trim()); }
            int qi = target.indexOf('?');
            String path = qi >= 0 ? target.substring(0, qi) : target;
            Map<String, String> q = query(qi >= 0 ? target.substring(qi + 1) : null);
            String pre = "/" + token;
            if (!path.equals(pre) && !path.startsWith(pre + "/")) { text(out, 403, "Forbidden", "text/html", "<meta charset=utf-8><body style='font:16px sans-serif;background:#09080f;color:#eee;padding:40px'>Неверная ссылка. Откройте адрес, показанный в приложении Neon Explorer.</body>"); return; }
            String sub = path.substring(pre.length());
            if (sub.isEmpty()) { head(out, 302, "Found", null, 0, "Location: " + pre + "/\r\n"); return; }
            switch (sub) {
                case "/": text(out, 200, "OK", "text/html", page); return;
                case "/api/roots": {
                    JSONArray a = new JSONArray();
                    for (File r : host.roots()) a.put(new JSONObject().put("path", r.getAbsolutePath()).put("name", r.getName()));
                    text(out, 200, "OK", "application/json", new JSONObject().put("roots", a).put("upload", upload).toString());
                    return;
                }
                case "/api/list": {
                    File d = new File(q.getOrDefault("p", ""));
                    if (!inRoots(d) || !d.isDirectory()) { text(out, 404, "Not Found", "application/json", "{\"error\":\"Папка не найдена\"}"); return; }
                    JSONArray a = new JSONArray();
                    File[] ch = d.listFiles();
                    if (ch != null) for (File f : ch) {
                        if (f.getName().startsWith(".")) continue;
                        a.put(new JSONArray().put(f.getName()).put(f.isDirectory() ? 1 : 0).put(f.isDirectory() ? 0 : f.length()).put(f.lastModified()));
                    }
                    text(out, 200, "OK", "application/json", new JSONObject().put("path", d.getAbsolutePath()).put("items", a).toString());
                    return;
                }
                case "/dl": { download(out, new File(q.getOrDefault("p", "")), hdr.get("range"), q.containsKey("view")); return; }
                case "/up": {
                    if (!upload) { text(out, 403, "Forbidden", "application/json", "{\"error\":\"Загрузка на телефон выключена\"}"); return; }
                    File d = new File(q.getOrDefault("p", ""));
                    String name = Util.safeName(q.getOrDefault("n", "file"));
                    if (!inRoots(d) || !d.isDirectory()) { text(out, 404, "Not Found", "application/json", "{\"error\":\"Папка не найдена\"}"); return; }
                    long len = Long.parseLong(hdr.getOrDefault("content-length", "-1"));
                    if (len < 0) { text(out, 411, "Length Required", "application/json", "{\"error\":\"Нужен Content-Length\"}"); return; }
                    File tmp = new File(d, "." + name + ".part");
                    boolean ok = false;
                    try (OutputStream fo = new FileOutputStream(tmp)) {
                        byte[] buf = new byte[1 << 17]; long left = len;
                        while (left > 0) { int n = in.read(buf, 0, (int) Math.min(buf.length, left)); if (n < 0) break; fo.write(buf, 0, n); left -= n; }
                        ok = left == 0;
                    } finally { if (!ok) tmp.delete(); }
                    if (!ok) return;
                    File t = Util.unique(d, name);
                    if (!tmp.renameTo(t)) { tmp.delete(); text(out, 500, "Error", "application/json", "{\"error\":\"Не удалось сохранить\"}"); return; }
                    JSONObject ev = new JSONObject().put("type", "share").put("action", "upload").put("name", t.getName()).put("path", t.getAbsolutePath()).put("dir", d.getAbsolutePath());
                    host.emit(ev);
                    text(out, 200, "OK", "application/json", new JSONObject().put("ok", true).put("name", t.getName()).toString());
                    return;
                }
                case "/mkdir": {
                    if (!upload) { text(out, 403, "Forbidden", "application/json", "{\"error\":\"Изменения выключены\"}"); return; }
                    File d = new File(q.getOrDefault("p", ""));
                    if (!inRoots(d)) { text(out, 404, "Not Found", "application/json", "{}"); return; }
                    File n = new File(d, Util.safeName(q.getOrDefault("n", "Новая папка")));
                    boolean ok = n.mkdirs() || n.isDirectory();
                    text(out, ok ? 200 : 500, ok ? "OK" : "Error", "application/json", "{\"ok\":" + ok + "}");
                    return;
                }
                default: text(out, 404, "Not Found", "text/plain", "404");
            }
        } finally { try { out.flush(); } catch (IOException ignored) { } }
    }

    void download(OutputStream out, File f, String range, boolean inline) throws Exception {
        if (!inRoots(f) || !f.exists()) { text(out, 404, "Not Found", "text/plain", "Файл не найден"); return; }
        String enc = URLEncoder.encode(f.getName() + (f.isDirectory() ? ".zip" : ""), "UTF-8").replace("+", "%20");
        if (f.isDirectory()) {
            head(out, 200, "OK", "application/zip", -1, "Content-Disposition: attachment; filename*=UTF-8''" + enc + "\r\n");
            ZipOutputStream z = new ZipOutputStream(out);
            zipDir(z, f, f.getName());
            z.finish();
            z.flush();
            return;
        }
        long total = f.length(), start = 0, end = total - 1;
        boolean partial = false;
        if (range != null && range.startsWith("bytes=") && total > 0) {
            String[] p = range.substring(6).split("-", 2);
            try {
                if (p[0].trim().isEmpty()) { start = Math.max(0, total - Long.parseLong(p[1].trim())); }
                else { start = Long.parseLong(p[0].trim()); if (p.length > 1 && !p[1].trim().isEmpty()) end = Math.min(total - 1, Long.parseLong(p[1].trim())); }
                partial = start <= end;
            } catch (NumberFormatException ignored) { }
            if (!partial) { start = 0; end = total - 1; }
        }
        String extra = "Accept-Ranges: bytes\r\nContent-Disposition: " + (inline ? "inline" : "attachment") + "; filename*=UTF-8''" + enc + "\r\n";
        if (partial) extra += "Content-Range: bytes " + start + "-" + end + "/" + total + "\r\n";
        head(out, partial ? 206 : 200, partial ? "Partial Content" : "OK", Util.mime(f.getName()), end - start + 1, extra);
        try (InputStream fi = new FileInputStream(f)) {
            long sk = 0; while (sk < start) { long k = fi.skip(start - sk); if (k <= 0) break; sk += k; }
            byte[] buf = new byte[1 << 17]; long left = end - start + 1;
            while (left > 0) { int n = fi.read(buf, 0, (int) Math.min(buf.length, left)); if (n < 0) break; out.write(buf, 0, n); left -= n; }
        }
    }

    void zipDir(ZipOutputStream z, File f, String name) throws IOException {
        if (f.isDirectory()) {
            z.putNextEntry(new ZipEntry(name + "/")); z.closeEntry();
            File[] ch = f.listFiles();
            if (ch != null) for (File c : ch) if (!c.getName().startsWith(".")) zipDir(z, c, name + "/" + c.getName());
            return;
        }
        ZipEntry e = new ZipEntry(name); e.setTime(f.lastModified());
        z.putNextEntry(e);
        try (InputStream in = new FileInputStream(f)) { Util.copy(in, z); }
        z.closeEntry();
    }
}
