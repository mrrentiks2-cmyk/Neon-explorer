package app.neonexplorer;

/** Same screen, started by other apps to pick a file ("Выбрать файл"); standard launch mode so the result returns. */
public class PickerActivity extends MainActivity { }
