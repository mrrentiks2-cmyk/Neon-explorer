package app.neonexplorer;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.Deflater;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/** Background file operations with progress, conflicts and cancel. */
class Ops {
    interface Host {
        void emit(JSONObject o);
        boolean allowed(File f);
        File volumeRoot(File f);
        void scan(List<String> paths);
    }

    static final String TRASH = ".NeonTrash";
    final Host host;
    final Map<String, Op> running = new ConcurrentHashMap<>();
    final ExecutorService exec = Executors.newFixedThreadPool(2);

    Ops(Host h) { host = h; }

    void start(String json) {
        try {
            Op op = new Op(new JSONObject(json));
            running.put(op.id, op);
            exec.execute(op);
        } catch (Exception e) {
            JSONObject o = new JSONObject();
            try { o.put("type", "op"); o.put("state", "done"); o.put("ok", false); o.put("errors", new JSONArray().put(String.valueOf(e.getMessage()))); } catch (Exception ignored) { }
            host.emit(o);
        }
    }

    void answer(String id, String choice, boolean all) {
        Op op = running.get(id);
        if (op == null) return;
        synchronized (op.lock) { op.answer = choice; if (all) op.allChoice = choice; op.lock.notifyAll(); }
    }

    void cancel(String id) {
        Op op = running.get(id);
        if (op == null) return;
        synchronized (op.lock) { op.cancel = true; op.lock.notifyAll(); }
    }

    static class Cancelled extends RuntimeException { }

    /* ---------- trash index ---------- */
    static synchronized JSONObject loadIndex(File trashDir) {
        File f = new File(trashDir, ".index.json");
        try (InputStream in = new FileInputStream(f)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            Util.copy(in, bo);
            return new JSONObject(bo.toString("UTF-8"));
        } catch (Exception e) { return new JSONObject(); }
    }

    static synchronized void saveIndex(File trashDir, JSONObject idx) {
        File f = new File(trashDir, ".index.json"), tmp = new File(trashDir, ".index.tmp");
        try (OutputStream o = new FileOutputStream(tmp)) { o.write(idx.toString().getBytes(StandardCharsets.UTF_8)); }
        catch (Exception e) { return; }
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f); }
    }

    static File trashDir(File volRoot) {
        File d = new File(volRoot, TRASH);
        if (!d.exists()) { d.mkdirs(); try { new File(d, ".nomedia").createNewFile(); } catch (IOException ignored) { } }
        return d;
    }

    /* ---------- archives ---------- */
    static ZipFile openZip(File f) throws IOException {
        IOException last = null;
        for (String cs : new String[]{"UTF-8", "IBM866", "windows-1251", "ISO-8859-1"}) {
            ZipFile z = null;
            try {
                if (!Charset.isSupported(cs)) continue;
                z = new ZipFile(f, Charset.forName(cs));
                Enumeration<? extends ZipEntry> en = z.entries();
                while (en.hasMoreElements()) en.nextElement().getName();
                return z;
            } catch (IllegalArgumentException e) {
                if (z != null) try { z.close(); } catch (IOException ignored) { }
            } catch (IOException e) {
                if (z != null) try { z.close(); } catch (IOException ignored) { }
                last = e;
                if (!String.valueOf(e.getMessage()).toLowerCase().contains("name")) throw e;
            }
        }
        throw last != null ? last : new IOException("Не удалось открыть архив");
    }

    static boolean isZipLike(String e) { return e.equals("zip") || e.equals("jar") || e.equals("apk") || e.equals("apks") || e.equals("xapk") || e.equals("cbz") || e.equals("epub") || e.equals("docx") || e.equals("xlsx") || e.equals("pptx") || e.equals("odt"); }

    static boolean isTarGz(String name) { String n = name.toLowerCase(); return n.endsWith(".tar.gz") || n.endsWith(".tgz"); }

    /* ======================================================================= */
    class Op implements Runnable {
        final String id, type;
        final JSONObject spec;
        final List<File> src = new ArrayList<>();
        File dst;
        volatile boolean cancel;
        long total, done;
        int nFiles, doneFiles, count;
        String cur = "";
        String allChoice, answer;
        final Object lock = new Object();
        long lastEmit;
        final List<String> errors = new ArrayList<>();
        final List<String> scanPaths = new ArrayList<>();
        String resultPath;

        Op(JSONObject s) throws Exception {
            spec = s;
            id = s.getString("id");
            type = s.getString("type");
            JSONArray a = s.optJSONArray("src");
            if (a != null) for (int i = 0; i < a.length(); i++) src.add(new File(a.getString(i)));
            if (s.has("dst")) dst = new File(s.getString("dst"));
            String c = s.optString("conflict", "");
            if (!c.isEmpty() && !c.equals("ask")) allChoice = c;
        }

        void emit(String state) {
            JSONObject o = new JSONObject();
            try {
                o.put("type", "op"); o.put("id", id); o.put("state", state); o.put("op", type);
                o.put("done", done); o.put("total", total); o.put("files", doneFiles); o.put("nfiles", nFiles); o.put("cur", cur);
            } catch (Exception ignored) { }
            host.emit(o);
        }

        void tick(boolean force) {
            if (cancel) throw new Cancelled();
            long now = System.currentTimeMillis();
            if (force || now - lastEmit > 150) { lastEmit = now; emit("progress"); }
        }

        void scanAdd(File f) { if (scanPaths.size() < 4000) scanPaths.add(f.getAbsolutePath()); }

        void measure(File f) {
            if (cancel) throw new Cancelled();
            if (f.isDirectory() && !Util.isSymlink(f)) {
                File[] ch = f.listFiles();
                if (ch != null) for (File c : ch) measure(c);
            } else { total += f.length(); nFiles++; }
        }

        void collectScan(File f) {
            if (scanPaths.size() >= 4000) return;
            if (f.isDirectory()) { File[] ch = f.listFiles(); if (ch != null) for (File c : ch) collectScan(c); }
            else scanAdd(f);
        }

        void check(File f) throws IOException { if (!host.allowed(f)) throw new IOException("Нет доступа: " + f.getName()); }

        /** what to do with an existing target: returns the file to write, or null to skip */
        File resolve(File s, File t) {
            if (s != null && s.getAbsoluteFile().equals(t.getAbsoluteFile())) return Util.unique(t.getParentFile(), t.getName());
            String ch = allChoice;
            if (ch == null) {
                synchronized (lock) {
                    answer = null;
                    JSONObject o = new JSONObject();
                    try {
                        o.put("type", "op"); o.put("id", id); o.put("state", "conflict"); o.put("op", type);
                        o.put("name", t.getName()); o.put("dir", t.isDirectory());
                        o.put("dstSize", t.isDirectory() ? 0 : t.length()); o.put("dstTime", t.lastModified());
                        if (s != null) { o.put("srcSize", s.length()); o.put("srcTime", s.lastModified()); }
                    } catch (Exception ignored) { }
                    host.emit(o);
                    while (answer == null && !cancel) { try { lock.wait(); } catch (InterruptedException e) { cancel = true; } }
                    if (cancel) throw new Cancelled();
                    ch = answer;
                }
            }
            if ("skip".equals(ch)) return null;
            if ("rename".equals(ch)) return Util.unique(t.getParentFile(), t.getName());
            Util.deleteTree(t);
            return t;
        }

        void copyFile(File s, File t, boolean move) throws IOException {
            cur = s.getName();
            File parent = t.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            boolean ok = false;
            try (InputStream in = new FileInputStream(s); OutputStream out = new FileOutputStream(t)) {
                byte[] buf = new byte[1 << 18];
                int n;
                while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); done += n; tick(false); }
                ok = true;
            } finally { if (!ok) t.delete(); }
            t.setLastModified(s.lastModified());
            doneFiles++;
            scanAdd(t);
            if (move) { if (s.delete()) scanAdd(s); else errors.add("Не удалось удалить исходный файл " + s.getName()); }
            tick(false);
        }

        void copyTree(File s, File t, boolean move) throws IOException {
            if (cancel) throw new Cancelled();
            if (s.isDirectory() && !Util.isSymlink(s)) {
                if (t.exists() && !t.isDirectory()) { t = resolve(s, t); if (t == null) { skip(s); return; } }
                if (!t.exists() && !t.mkdirs()) throw new IOException("Не удалось создать папку «" + t.getName() + "»");
                File[] ch = s.listFiles();
                if (ch != null) for (File c : ch) {
                    try { copyTree(c, new File(t, c.getName()), move); }
                    catch (Cancelled e) { throw e; }
                    catch (IOException e) { errors.add(e.getMessage()); }
                }
                t.setLastModified(s.lastModified());
                if (move) { String[] left = s.list(); if (left == null || left.length == 0) s.delete(); }
            } else {
                if (t.exists()) { t = resolve(s, t); if (t == null) { done += s.length(); doneFiles++; return; } }
                copyFile(s, t, move);
            }
        }

        void skip(File f) { long[] st = new long[2]; sizeOf(f, st); done += st[0]; doneFiles += (int) st[1]; }

        void sizeOf(File f, long[] st) {
            if (f.isDirectory()) { File[] ch = f.listFiles(); if (ch != null) for (File c : ch) sizeOf(c, st); }
            else { st[0] += f.length(); st[1]++; }
        }

        void deleteTree(File f) {
            if (cancel) throw new Cancelled();
            if (f.isDirectory() && !Util.isSymlink(f)) {
                File[] ch = f.listFiles();
                if (ch != null) for (File c : ch) deleteTree(c);
            } else { done += f.length(); doneFiles++; cur = f.getName(); scanAdd(f); tick(false); }
            if (!f.delete() && f.exists()) errors.add("Не удалось удалить «" + f.getName() + "»");
        }

        @Override
        public void run() {
            boolean cancelled = false;
            try {
                for (File f : src) check(f);
                if (dst != null) check(dst);
                emit("start");
                switch (type) {
                    case "copy": case "move": doCopy(type.equals("move")); break;
                    case "delete": for (File f : src) measure(f); tick(true); for (File f : src) { deleteTree(f); count++; } break;
                    case "trash": doTrash(); break;
                    case "restore": doRestore(); break;
                    case "purge": doPurge(); break;
                    case "zip": doZip(); break;
                    case "unzip": doUnzip(); break;
                    case "copyas": doCopyAs(); break;
                    default: throw new IOException("Неизвестная операция");
                }
            } catch (Cancelled e) {
                cancelled = true;
            } catch (Throwable e) {
                errors.add(e.getMessage() == null ? e.toString() : e.getMessage());
            } finally {
                running.remove(id);
                if (!scanPaths.isEmpty()) host.scan(new ArrayList<>(scanPaths));
                JSONObject o = new JSONObject();
                try {
                    o.put("type", "op"); o.put("id", id); o.put("state", "done"); o.put("op", type);
                    o.put("ok", errors.isEmpty() && !cancelled); o.put("cancelled", cancelled); o.put("count", count);
                    o.put("done", done); o.put("total", total); o.put("files", doneFiles);
                    JSONArray er = new JSONArray(); for (int i = 0; i < Math.min(6, errors.size()); i++) er.put(errors.get(i));
                    o.put("errors", er); o.put("nerrors", errors.size());
                    if (resultPath != null) o.put("result", resultPath);
                } catch (Exception ignored) { }
                host.emit(o);
            }
        }

        void doCopy(boolean move) throws IOException {
            if (dst == null) throw new IOException("Не указана папка назначения");
            if (!dst.exists() && !dst.mkdirs()) throw new IOException("Папка назначения недоступна");
            if (!dst.canWrite()) throw new IOException("Нет прав на запись в «" + dst.getName() + "»");
            for (File f : src) {
                if (f.isDirectory() && Util.isInside(dst, f)) throw new IOException("Нельзя " + (move ? "переместить" : "скопировать") + " папку «" + f.getName() + "» внутрь самой себя");
            }
            // fast path: rename inside one volume
            List<File> rest = new ArrayList<>();
            for (File f : src) {
                File t = new File(dst, f.getName());
                if (move && f.getParentFile() != null && f.getParentFile().getAbsoluteFile().equals(dst.getAbsoluteFile())) { count++; continue; }
                if (move && !t.exists() && f.getParentFile() != null && !f.getParentFile().getAbsoluteFile().equals(dst.getAbsoluteFile())) {
                    List<String> before = new ArrayList<>();
                    if (f.isDirectory()) { int mark = scanPaths.size(); collectScan(f); before.addAll(scanPaths.subList(mark, scanPaths.size())); }
                    if (f.renameTo(t)) {
                        count++;
                        if (f.isDirectory()) { collectScan(t); } else { scanAdd(f); scanAdd(t); }
                        continue;
                    }
                    // rename failed: undo the scan list growth
                    if (!before.isEmpty()) scanPaths.subList(scanPaths.size() - before.size(), scanPaths.size()).clear();
                }
                rest.add(f);
            }
            for (File f : rest) measure(f);
            tick(true);
            for (File f : rest) {
                if (cancel) throw new Cancelled();
                try { copyTree(f, new File(dst, f.getName()), move); count++; }
                catch (Cancelled e) { throw e; }
                catch (IOException e) { errors.add(e.getMessage()); }
            }
            resultPath = dst.getAbsolutePath();
        }

        void doTrash() throws IOException {
            for (File f : src) measure(f);
            tick(true);
            for (File f : src) {
                if (cancel) throw new Cancelled();
                File root = host.volumeRoot(f);
                if (root == null) { errors.add("«" + f.getName() + "»: корзина недоступна в этом месте"); continue; }
                File td = trashDir(root);
                if (Util.isInside(f, td)) { errors.add("Файл уже в корзине"); continue; }
                String tname = System.currentTimeMillis() + "_" + f.getName();
                File t = new File(td, tname);
                long[] st = new long[2]; sizeOf(f, st);
                int mark = scanPaths.size(); collectScan(f);
                cur = f.getName();
                boolean moved = f.renameTo(t);
                if (!moved) {
                    scanPaths.subList(mark, scanPaths.size()).clear();
                    copyTree(f, t, true);
                    moved = !f.exists();
                } else { done += st[0]; doneFiles += (int) st[1]; }
                if (moved || t.exists()) {
                    synchronized (Ops.class) {
                        JSONObject idx = loadIndex(td);
                        JSONObject e = new JSONObject();
                        try { e.put("o", f.getAbsolutePath()); e.put("t", System.currentTimeMillis()); e.put("s", st[0]); e.put("d", t.isDirectory() ? 1 : 0); e.put("n", st[1]); idx.put(tname, e); } catch (Exception ignored) { }
                        saveIndex(td, idx);
                    }
                    count++;
                }
                tick(false);
            }
        }

        void doRestore() throws IOException {
            for (File f : src) measure(f);
            tick(true);
            for (File f : src) {
                if (cancel) throw new Cancelled();
                File td = f.getParentFile();
                String orig;
                synchronized (Ops.class) { JSONObject idx = loadIndex(td); JSONObject e = idx.optJSONObject(f.getName()); orig = e == null ? null : e.optString("o", null); }
                if (orig == null) {
                    String n = f.getName(); int u = n.indexOf('_');
                    orig = new File(Environmentish.downloads(), u > 0 ? n.substring(u + 1) : n).getAbsolutePath();
                }
                File t = new File(orig);
                File parent = t.getParentFile();
                if (parent != null && !parent.exists()) parent.mkdirs();
                if (t.exists()) t = Util.unique(parent, t.getName());
                cur = t.getName();
                if (!f.renameTo(t)) copyTree(f, t, true);
                else { long[] st = new long[2]; sizeOf(t, st); done += st[0]; doneFiles += (int) st[1]; }
                collectScan(t);
                synchronized (Ops.class) { JSONObject idx = loadIndex(td); idx.remove(f.getName()); saveIndex(td, idx); }
                count++;
                tick(false);
            }
        }

        void doPurge() {
            for (File f : src) measure(f);
            tick(true);
            for (File f : src) {
                File td = f.getParentFile();
                deleteTree(f);
                synchronized (Ops.class) { JSONObject idx = loadIndex(td); idx.remove(f.getName()); saveIndex(td, idx); }
                count++;
            }
        }

        void doCopyAs() throws IOException {
            File s = src.get(0);
            measure(s);
            tick(true);
            File parent = dst.getParentFile();
            if (parent != null) parent.mkdirs();
            File t = dst.exists() ? Util.unique(parent, dst.getName()) : dst;
            copyFile(s, t, false);
            resultPath = t.getAbsolutePath();
            count = 1;
        }

        /* ---------- zip ---------- */
        void doZip() throws IOException {
            File parent = dst.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            File t = dst.exists() ? Util.unique(parent, dst.getName()) : dst;
            for (File f : src) measure(f);
            tick(true);
            boolean ok = false;
            try (ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(t), 1 << 16))) {
                for (File f : src) { addZip(zos, f, f.getName(), t); count++; }
                ok = true;
            } finally { if (!ok) t.delete(); }
            scanAdd(t);
            resultPath = t.getAbsolutePath();
        }

        void addZip(ZipOutputStream zos, File f, String name, File self) throws IOException {
            if (cancel) throw new Cancelled();
            if (f.getAbsoluteFile().equals(self.getAbsoluteFile())) return;
            if (f.isDirectory()) {
                ZipEntry e = new ZipEntry(name + "/"); e.setTime(f.lastModified()); zos.putNextEntry(e); zos.closeEntry();
                File[] ch = f.listFiles();
                if (ch != null) for (File c : ch) addZip(zos, c, name + "/" + c.getName(), self);
                return;
            }
            cur = f.getName();
            String e = Util.ext(f.getName());
            zos.setLevel(Util.in(e, Util.IMG) || Util.in(e, Util.VID) || Util.in(e, Util.AUD) || Util.in(e, Util.ARC) || e.equals("apk") ? Deflater.BEST_SPEED : Deflater.DEFAULT_COMPRESSION);
            ZipEntry ze = new ZipEntry(name);
            ze.setTime(f.lastModified());
            zos.putNextEntry(ze);
            try (InputStream in = new FileInputStream(f)) {
                byte[] buf = new byte[1 << 17]; int n;
                while ((n = in.read(buf)) > 0) { zos.write(buf, 0, n); done += n; tick(false); }
            }
            zos.closeEntry();
            doneFiles++;
        }

        /* ---------- extract ---------- */
        boolean wanted(String name, JSONArray only) {
            if (only == null) return true;
            for (int i = 0; i < only.length(); i++) {
                String p = only.optString(i);
                if (name.equals(p) || name.startsWith(p.endsWith("/") ? p : p + "/")) return true;
            }
            return false;
        }

        File outFile(File outDir, String name) throws IOException {
            File out = new File(outDir, name);
            if (!Util.isInside(out, outDir)) throw new IOException("Небезопасный путь в архиве: " + name);
            return out;
        }

        void writeEntry(InputStream in, File out, long time) throws IOException {
            if (out.exists()) { out = resolve(null, out); if (out == null) return; }
            File p = out.getParentFile();
            if (p != null && !p.exists()) p.mkdirs();
            cur = out.getName();
            boolean ok = false;
            try (OutputStream o = new BufferedOutputStream(new FileOutputStream(out), 1 << 16)) {
                byte[] buf = new byte[1 << 17]; int n;
                while ((n = in.read(buf)) > 0) { o.write(buf, 0, n); done += n; tick(false); }
                ok = true;
            } finally { if (!ok) out.delete(); }
            if (time > 0) out.setLastModified(time);
            doneFiles++;
            scanAdd(out);
        }

        void doUnzip() throws IOException {
            File arc = src.get(0);
            String name = arc.getName(), e = Util.ext(name);
            JSONArray only = spec.optJSONArray("entries");
            File outDir = dst;
            if (!outDir.exists() && !outDir.mkdirs()) throw new IOException("Не удалось создать папку для распаковки");
            resultPath = outDir.getAbsolutePath();
            if (isZipLike(e)) {
                try (ZipFile zf = openZip(arc)) {
                    Enumeration<? extends ZipEntry> en = zf.entries();
                    while (en.hasMoreElements()) { ZipEntry z = en.nextElement(); if (!z.isDirectory() && wanted(z.getName(), only)) { total += Math.max(0, z.getSize()); nFiles++; } }
                    tick(true);
                    en = zf.entries();
                    while (en.hasMoreElements()) {
                        ZipEntry z = en.nextElement();
                        if (!wanted(z.getName(), only)) continue;
                        File out = outFile(outDir, z.getName());
                        if (z.isDirectory()) { out.mkdirs(); continue; }
                        try (InputStream in = zf.getInputStream(z)) { writeEntry(in, out, z.getTime()); }
                        count++;
                    }
                }
            } else if (e.equals("tar") || isTarGz(name)) {
                total = arc.length(); tick(true);
                try (InputStream raw = new BufferedInputStream(new FileInputStream(arc), 1 << 16)) {
                    InputStream in = isTarGz(name) ? new GZIPInputStream(raw, 1 << 16) : raw;
                    untar(in, outDir, only);
                }
            } else if (e.equals("gz")) {
                total = arc.length(); tick(true);
                String outName = name.substring(0, name.length() - 3);
                try (InputStream in = new GZIPInputStream(new BufferedInputStream(new FileInputStream(arc)), 1 << 16)) {
                    writeEntry(in, outFile(outDir, outName.isEmpty() ? "file" : outName), arc.lastModified());
                }
                count = 1;
            } else throw new IOException("Формат «" + e + "» не поддерживается. Поддерживаются ZIP, TAR, TAR.GZ и GZ");
        }

        void untar(InputStream in, File outDir, JSONArray only) throws IOException {
            byte[] hdr = new byte[512];
            String longName = null;
            while (true) {
                if (cancel) throw new Cancelled();
                if (!readFully(in, hdr)) break;
                boolean empty = true;
                for (byte b : hdr) if (b != 0) { empty = false; break; }
                if (empty) break;
                String name = str(hdr, 0, 100);
                String prefix = str(hdr, 345, 155);
                if (!prefix.isEmpty() && hdr[257] == 'u') name = prefix + "/" + name;
                long size = octal(hdr, 124, 12);
                long mtime = octal(hdr, 136, 12) * 1000;
                char tf = (char) hdr[156];
                if (tf == 'L') { byte[] ln = new byte[(int) size]; readFully(in, ln); skipPad(in, size); longName = new String(ln, StandardCharsets.UTF_8).replace("\u0000", ""); continue; }
                if (longName != null) { name = longName; longName = null; }
                if (tf == '5' || name.endsWith("/")) { if (wanted(name, only)) outFile(outDir, name).mkdirs(); skipFully(in, size); skipPad(in, size); continue; }
                if (tf == '0' || tf == 0 || tf == '7') {
                    Util.Limited lim = new Util.Limited(in, size) { @Override public void close() { } };
                    if (wanted(name, only)) { writeEntry(lim, outFile(outDir, name), mtime); count++; }
                    byte[] drain = new byte[8192];
                    while (lim.read(drain) > 0) { }
                    skipPad(in, size);
                } else { skipFully(in, size); skipPad(in, size); }
            }
        }

        boolean readFully(InputStream in, byte[] b) throws IOException {
            int off = 0;
            while (off < b.length) { int n = in.read(b, off, b.length - off); if (n < 0) return off > 0 && false; off += n; }
            return true;
        }

        void skipFully(InputStream in, long n) throws IOException { while (n > 0) { long k = in.skip(n); if (k <= 0) { if (in.read() < 0) break; k = 1; } n -= k; } }

        void skipPad(InputStream in, long size) throws IOException { long pad = (512 - size % 512) % 512; skipFully(in, pad); }

        String str(byte[] b, int off, int len) {
            int end = off; while (end < off + len && b[end] != 0) end++;
            return new String(b, off, end - off, StandardCharsets.UTF_8).trim();
        }

        long octal(byte[] b, int off, int len) {
            long v = 0;
            for (int i = off; i < off + len; i++) { byte c = b[i]; if (c == 0 || c == ' ') { if (v > 0) break; continue; } if (c < '0' || c > '7') break; v = v * 8 + (c - '0'); }
            return v;
        }
    }

    /** tiny indirection so Ops does not depend on Context */
    static final class Environmentish {
        static File downloads() { return android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS); }
    }
}
