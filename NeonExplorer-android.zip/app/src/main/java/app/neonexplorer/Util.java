package app.neonexplorer;

import android.webkit.MimeTypeMap;
import android.webkit.WebResourceResponse;

import org.json.JSONArray;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Small static helpers shared by the file engine. */
final class Util {
    private Util() { }

    static final String[] IMG = {"jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp", "avif", "dng"};
    static final String[] VID = {"mp4", "mkv", "webm", "3gp", "mov", "avi", "m4v", "ts", "flv", "wmv"};
    static final String[] AUD = {"mp3", "m4a", "aac", "ogg", "opus", "wav", "flac", "amr", "wma", "mid", "midi", "oga"};
    static final String[] DOC = {"pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "txt", "rtf", "csv", "md", "epub", "fb2", "djvu", "json", "xml", "html", "htm", "log"};
    static final String[] ARC = {"zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "jar"};

    static String ext(String name) {
        int d = name.lastIndexOf('.');
        return d > 0 && d < name.length() - 1 ? name.substring(d + 1).toLowerCase(Locale.ROOT) : "";
    }

    static boolean in(String e, String[] list) { for (String s : list) if (s.equals(e)) return true; return false; }

    /** images | video | audio | docs | archives | apk | other */
    static String cat(String name) {
        String e = ext(name);
        if (in(e, IMG)) return "images";
        if (in(e, VID)) return "video";
        if (in(e, AUD)) return "audio";
        if (in(e, DOC)) return "docs";
        if (in(e, ARC)) return "archives";
        if (e.equals("apk") || e.equals("apks") || e.equals("xapk")) return "apk";
        return "other";
    }

    static String mime(String name) {
        String e = ext(name);
        switch (e) {
            case "mkv": return "video/x-matroska";
            case "md": case "log": case "ini": case "conf": case "cfg": case "srt": case "sub": return "text/plain";
            case "apk": return "application/vnd.android.package-archive";
            case "heic": return "image/heic";
            case "heif": return "image/heif";
            case "avif": return "image/avif";
            case "opus": return "audio/ogg";
            case "flac": return "audio/flac";
            case "fb2": return "application/x-fictionbook+xml";
            default: break;
        }
        String m = e.isEmpty() ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(e);
        return m == null ? "application/octet-stream" : m;
    }

    static String safeName(String n) {
        n = n == null ? "" : n.replaceAll("[\\\\/:*?\"<>|\\u0000-\\u001f]", "_").trim();
        if (n.equals(".") || n.equals("..")) n = "_";
        return n.isEmpty() ? "file" : n;
    }

    /** "name (1).ext", "name (2).ext", ... */
    static File unique(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        String base = name, ext = "";
        int d = name.lastIndexOf('.');
        if (d > 0 && !new File(dir, name).isDirectory()) { base = name.substring(0, d); ext = name.substring(d); }
        for (int i = 1; ; i++) { f = new File(dir, base + " (" + i + ")" + ext); if (!f.exists()) return f; }
    }

    static boolean isInside(File child, File parent) {
        try {
            String c = child.getCanonicalPath(), p = parent.getCanonicalPath();
            return c.equals(p) || c.startsWith(p.endsWith("/") ? p : p + "/");
        } catch (IOException e) { return false; }
    }

    static boolean deleteTree(File f) {
        if (f.isDirectory() && !isSymlink(f)) {
            File[] ch = f.listFiles();
            if (ch != null) for (File c : ch) deleteTree(c);
        }
        return f.delete() || !f.exists();
    }

    static boolean isSymlink(File f) {
        try { return java.nio.file.Files.isSymbolicLink(f.toPath()); } catch (Throwable e) { return false; }
    }

    static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format(Locale.ROOT, "%02x", x));
        return sb.toString();
    }

    static String sha1(String s) {
        try { return hex(MessageDigest.getInstance("SHA-1").digest(s.getBytes("UTF-8"))); } catch (Exception e) { return String.valueOf(s.hashCode()); }
    }

    static long copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[1 << 17];
        long t = 0; int n;
        while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); t += n; }
        return t;
    }

    static WebResourceResponse bytes(String mime, byte[] data, boolean cache) {
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", cache ? "max-age=31536000" : "no-store");
        h.put("Access-Control-Allow-Origin", "*");
        return new WebResourceResponse(mime, null, 200, "OK", h, new ByteArrayInputStream(data));
    }

    static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not found", new HashMap<>(), new ByteArrayInputStream(new byte[0]));
    }

    static class Limited extends FilterInputStream {
        long left;
        Limited(InputStream in, long n) { super(in); left = n; }
        @Override public int read() throws IOException { if (left <= 0) return -1; int r = super.read(); if (r >= 0) left--; return r; }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int r = super.read(b, off, (int) Math.min(len, left));
            if (r > 0) left -= r;
            return r;
        }
    }

    interface Opener { InputStream open() throws IOException; }

    /** stream with HTTP Range support (video/audio seeking) */
    static WebResourceResponse ranged(Opener op, long total, String mime, Map<String, String> req) throws IOException {
        String range = null;
        if (req != null) for (Map.Entry<String, String> e : req.entrySet()) if ("range".equalsIgnoreCase(e.getKey())) range = e.getValue();
        Map<String, String> h = new HashMap<>();
        h.put("Accept-Ranges", "bytes");
        h.put("Cache-Control", "no-store");
        h.put("Access-Control-Allow-Origin", "*");
        if (range != null && range.startsWith("bytes=") && total > 0) {
            String[] p = range.substring(6).split("-", 2);
            long start, end;
            if (p[0].trim().isEmpty()) { start = Math.max(0, total - Long.parseLong(p[1].trim())); end = total - 1; }
            else { start = Long.parseLong(p[0].trim()); end = p.length > 1 && !p[1].trim().isEmpty() ? Long.parseLong(p[1].trim()) : total - 1; }
            end = Math.min(end, total - 1);
            if (start > end) start = 0;
            InputStream in = op.open();
            long sk = 0;
            while (sk < start) { long k = in.skip(start - sk); if (k <= 0) break; sk += k; }
            h.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
            h.put("Content-Length", String.valueOf(end - start + 1));
            return new WebResourceResponse(mime, null, 206, "Partial Content", h, new Limited(in, end - start + 1));
        }
        if (total >= 0) h.put("Content-Length", String.valueOf(total));
        return new WebResourceResponse(mime, null, 200, "OK", h, op.open());
    }

    static JSONArray row(File f, boolean withCount) {
        JSONArray r = new JSONArray();
        boolean d = f.isDirectory();
        r.put(f.getName());
        r.put(d ? 1 : 0);
        r.put(d ? 0 : f.length());
        r.put(f.lastModified());
        if (withCount && d) { String[] l = f.list(); r.put(l == null ? -1 : l.length); } else r.put(-1);
        return r;
    }
}
