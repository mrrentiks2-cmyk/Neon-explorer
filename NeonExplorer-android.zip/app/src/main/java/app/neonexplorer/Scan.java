package app.neonexplorer;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

/** Search, storage analysis, duplicates, folder sizes, hashes, MediaStore categories. */
class Scan {
    interface Host { void emit(JSONObject o); boolean allowed(File f); }

    final Context ctx;
    final Host host;
    final Map<String, AtomicBoolean> cancels = new ConcurrentHashMap<>();
    final ExecutorService exec = Executors.newFixedThreadPool(3);
    volatile Map<String, long[]> dirSizes = new HashMap<>();

    Scan(Context c, Host h) { ctx = c; host = h; }

    void cancel(String req) { AtomicBoolean b = cancels.get(req); if (b != null) b.set(true); }

    AtomicBoolean token(String req) { AtomicBoolean b = new AtomicBoolean(false); cancels.put(req, b); return b; }

    static JSONObject ev(String type, String req) {
        JSONObject o = new JSONObject();
        try { o.put("type", type); o.put("req", req); } catch (Exception ignored) { }
        return o;
    }

    static boolean skipDir(File d, boolean hidden) {
        String n = d.getName();
        if (n.equals(Ops.TRASH)) return true;
        if (!hidden && n.startsWith(".")) return true;
        String p = d.getAbsolutePath();
        return p.endsWith("/Android/data") || p.endsWith("/Android/obb");
    }

    static JSONArray frow(File f) {
        JSONArray r = new JSONArray();
        r.put(f.getAbsolutePath()); r.put(f.isDirectory() ? 1 : 0); r.put(f.isDirectory() ? 0 : f.length()); r.put(f.lastModified());
        return r;
    }

    /* ---------- folder size ---------- */
    void dirSize(String req, String path) {
        exec.execute(() -> {
            AtomicBoolean c = token(req);
            long[] st = new long[3];
            long[] last = {System.currentTimeMillis()};
            ArrayDeque<File> q = new ArrayDeque<>();
            File root = new File(path);
            if (host.allowed(root)) q.add(root);
            while (!q.isEmpty() && !c.get()) {
                File d = q.poll();
                File[] ch = d.listFiles();
                if (ch == null) continue;
                for (File f : ch) {
                    if (f.isDirectory()) { if (!Util.isSymlink(f)) { st[2]++; q.add(f); } }
                    else { st[0] += f.length(); st[1]++; }
                }
                if (System.currentTimeMillis() - last[0] > 400) { last[0] = System.currentTimeMillis(); emitSize(req, st, false); }
            }
            cancels.remove(req);
            emitSize(req, st, true);
        });
    }

    void emitSize(String req, long[] st, boolean done) {
        JSONObject o = ev("dirsize", req);
        try { o.put("size", st[0]); o.put("files", st[1]); o.put("dirs", st[2]); o.put("done", done); } catch (Exception ignored) { }
        host.emit(o);
    }

    /* ---------- hashes ---------- */
    void hash(String req, String path, String algo) {
        exec.execute(() -> {
            AtomicBoolean c = token(req);
            JSONObject o = ev("hash", req);
            try {
                File f = new File(path);
                if (!host.allowed(f)) throw new Exception("Нет доступа");
                MessageDigest md = MessageDigest.getInstance(algo);
                long total = f.length(), done = 0, last = 0;
                try (InputStream in = new FileInputStream(f)) {
                    byte[] buf = new byte[1 << 18]; int n;
                    while ((n = in.read(buf)) > 0) {
                        if (c.get()) throw new Exception("Отменено");
                        md.update(buf, 0, n); done += n;
                        if (System.currentTimeMillis() - last > 300) {
                            last = System.currentTimeMillis();
                            JSONObject p = ev("hash", req); p.put("algo", algo); p.put("progress", total > 0 ? (double) done / total : 0); host.emit(p);
                        }
                    }
                }
                o.put("algo", algo); o.put("value", Util.hex(md.digest()));
            } catch (Exception e) { try { o.put("error", e.getMessage()); o.put("algo", algo); } catch (Exception ignored) { } }
            cancels.remove(req);
            host.emit(o);
        });
    }

    /* ---------- search ---------- */
    void search(String req, String root, String query, String filtersJson) {
        exec.execute(() -> {
            AtomicBoolean c = token(req);
            JSONObject fl;
            try { fl = new JSONObject(filtersJson == null || filtersJson.isEmpty() ? "{}" : filtersJson); } catch (Exception e) { fl = new JSONObject(); }
            String cat = fl.optString("cat", "");
            long min = fl.optLong("min", 0), max = fl.optLong("max", 0);
            int days = fl.optInt("days", 0);
            boolean hidden = fl.optBoolean("hidden", false);
            long since = days > 0 ? System.currentTimeMillis() - days * 86400000L : 0;
            String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
            Pattern glob = null;
            String[] toks = new String[0];
            if (q.contains("*") || q.contains("?")) {
                StringBuilder re = new StringBuilder();
                for (char ch : q.toCharArray()) { if (ch == '*') re.append(".*"); else if (ch == '?') re.append('.'); else re.append(Pattern.quote(String.valueOf(ch))); }
                glob = Pattern.compile(re.toString(), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            } else if (!q.isEmpty()) toks = q.split("\\s+");
            JSONArray batch = new JSONArray();
            int found = 0, scanned = 0;
            long last = System.currentTimeMillis();
            ArrayDeque<File> dq = new ArrayDeque<>();
            File r = new File(root);
            if (host.allowed(r)) dq.add(r);
            outer:
            while (!dq.isEmpty()) {
                if (c.get()) break;
                File d = dq.poll();
                File[] ch = d.listFiles();
                if (ch == null) continue;
                for (File f : ch) {
                    scanned++;
                    boolean dir = f.isDirectory();
                    String n = f.getName();
                    if (dir && !Util.isSymlink(f) && !skipDir(f, hidden)) dq.add(f);
                    if (!hidden && n.startsWith(".")) continue;
                    String ln = n.toLowerCase(Locale.ROOT);
                    if (glob != null) { if (!glob.matcher(n).matches()) continue; }
                    else { boolean ok = true; for (String t : toks) if (!ln.contains(t)) { ok = false; break; } if (!ok) continue; }
                    if (!cat.isEmpty()) {
                        if (cat.equals("folders")) { if (!dir) continue; }
                        else if (dir || !Util.cat(n).equals(cat)) continue;
                    }
                    if (!dir) {
                        long s = f.length();
                        if (min > 0 && s < min) continue;
                        if (max > 0 && s > max) continue;
                    }
                    if (since > 0 && f.lastModified() < since) continue;
                    batch.put(frow(f));
                    if (++found >= 3000) break outer;
                }
                if (batch.length() >= 60 || System.currentTimeMillis() - last > 350) {
                    last = System.currentTimeMillis();
                    emitSearch(req, batch, false, scanned, found);
                    batch = new JSONArray();
                }
            }
            cancels.remove(req);
            emitSearch(req, batch, true, scanned, found);
        });
    }

    void emitSearch(String req, JSONArray items, boolean done, int scanned, int found) {
        JSONObject o = ev("search", req);
        try { o.put("items", items); o.put("done", done); o.put("scanned", scanned); o.put("found", found); } catch (Exception ignored) { }
        host.emit(o);
    }

    /* ---------- storage analyzer ---------- */
    void analyze(String req, String root) {
        exec.execute(() -> {
            AtomicBoolean c = token(req);
            Map<String, long[]> sizes = new HashMap<>();
            Map<String, long[]> cats = new HashMap<>();
            for (String k : new String[]{"images", "video", "audio", "docs", "archives", "apk", "other"}) cats.put(k, new long[2]);
            PriorityQueue<Object[]> top = new PriorityQueue<>((a, b) -> Long.compare((Long) a[1], (Long) b[1]));
            List<String> empties = new ArrayList<>();
            long[] cnt = new long[3];
            long[] last = {System.currentTimeMillis()};
            File r = new File(root);
            long[] tot = walk(r, sizes, cats, top, empties, cnt, c, req, last);
            JSONObject o = ev("analyze", req);
            try {
                o.put("state", c.get() ? "cancelled" : "done");
                o.put("root", root); o.put("total", tot[0]); o.put("files", tot[1]); o.put("dirs", cnt[2]);
                JSONObject cj = new JSONObject();
                for (Map.Entry<String, long[]> e : cats.entrySet()) cj.put(e.getKey(), new JSONArray().put(e.getValue()[0]).put(e.getValue()[1]));
                o.put("cats", cj);
                List<Object[]> lf = new ArrayList<>(top);
                Collections.sort(lf, (a, b) -> Long.compare((Long) b[1], (Long) a[1]));
                JSONArray la = new JSONArray();
                for (Object[] x : lf) la.put(new JSONArray().put(x[0]).put(x[1]).put(x[2]));
                o.put("largest", la);
                JSONArray ea = new JSONArray(); for (String s : empties) ea.put(s);
                o.put("empties", ea);
                android.os.StatFs sf = new android.os.StatFs(root);
                o.put("capacity", sf.getTotalBytes()); o.put("free", sf.getAvailableBytes());
            } catch (Exception ignored) { }
            dirSizes = sizes;
            cancels.remove(req);
            host.emit(o);
        });
    }

    long[] walk(File d, Map<String, long[]> sizes, Map<String, long[]> cats, PriorityQueue<Object[]> top, List<String> empties, long[] cnt, AtomicBoolean c, String req, long[] last) {
        long size = 0, files = 0;
        File[] ch = d.listFiles();
        List<File> sub = new ArrayList<>();
        if (ch != null) for (File f : ch) {
            if (c.get()) break;
            if (f.isDirectory()) { if (!Util.isSymlink(f) && !f.getName().equals(Ops.TRASH)) sub.add(f); continue; }
            long s = f.length();
            size += s; files++; cnt[1]++;
            long[] k = cats.get(Util.cat(f.getName()));
            k[0] += s; k[1]++;
            if (top.size() < 100 || s > (Long) top.peek()[1]) { top.add(new Object[]{f.getAbsolutePath(), s, f.lastModified()}); if (top.size() > 100) top.poll(); }
        }
        List<String> zero = new ArrayList<>();
        for (File f : sub) {
            if (c.get()) break;
            cnt[2]++;
            long[] r = walk(f, sizes, cats, top, empties, cnt, c, req, last);
            size += r[0]; files += r[1];
            if (r[1] == 0) zero.add(f.getAbsolutePath());
        }
        if (files > 0 && empties.size() < 400) for (String z : zero) { if (empties.size() < 400) empties.add(z); }
        sizes.put(d.getAbsolutePath(), new long[]{size, files});
        if (System.currentTimeMillis() - last[0] > 350) {
            last[0] = System.currentTimeMillis();
            JSONObject o = ev("analyze", req);
            try { o.put("state", "progress"); o.put("files", cnt[1]); o.put("dirs", cnt[2]); o.put("cur", d.getName()); } catch (Exception ignored) { }
            host.emit(o);
        }
        return new long[]{size, files};
    }

    String analyzeDir(String path) {
        JSONArray a = new JSONArray();
        File d = new File(path);
        File[] ch = d.listFiles();
        Map<String, long[]> sz = dirSizes;
        List<Object[]> rows = new ArrayList<>();
        if (ch != null) for (File f : ch) {
            if (f.getName().equals(Ops.TRASH)) continue;
            if (f.isDirectory()) { long[] s = sz.get(f.getAbsolutePath()); rows.add(new Object[]{f.getName(), 1, s == null ? 0L : s[0], s == null ? 0L : s[1]}); }
            else rows.add(new Object[]{f.getName(), 0, f.length(), 1L});
        }
        Collections.sort(rows, (x, y) -> Long.compare((Long) y[2], (Long) x[2]));
        for (Object[] r : rows) a.put(new JSONArray().put(r[0]).put(r[1]).put(r[2]).put(r[3]));
        return a.toString();
    }

    /* ---------- duplicates ---------- */
    void dups(String req, String root, long minSize) {
        exec.execute(() -> {
            AtomicBoolean c = token(req);
            Map<Long, List<File>> bySize = new HashMap<>();
            ArrayDeque<File> dq = new ArrayDeque<>();
            dq.add(new File(root));
            long scanned = 0, last = System.currentTimeMillis();
            while (!dq.isEmpty() && !c.get()) {
                File d = dq.poll();
                File[] ch = d.listFiles();
                if (ch == null) continue;
                for (File f : ch) {
                    if (f.isDirectory()) { if (!Util.isSymlink(f) && !skipDir(f, false)) dq.add(f); continue; }
                    long s = f.length();
                    if (s < minSize) continue;
                    scanned++;
                    List<File> l = bySize.get(s);
                    if (l == null) bySize.put(s, l = new ArrayList<>(2));
                    l.add(f);
                }
                if (System.currentTimeMillis() - last > 350) { last = System.currentTimeMillis(); progress(req, "scan", scanned, 0); }
            }
            List<List<File>> cand = new ArrayList<>();
            long work = 0;
            for (List<File> l : bySize.values()) if (l.size() > 1) { cand.add(l); work += l.size(); }
            List<List<File>> groups = new ArrayList<>();
            long doneW = 0;
            for (List<File> l : cand) {
                if (c.get()) break;
                Map<String, List<File>> byQuick = new HashMap<>();
                for (File f : l) { String h = quickHash(f); if (h == null) continue; List<File> g = byQuick.get(h); if (g == null) byQuick.put(h, g = new ArrayList<>()); g.add(f); }
                for (List<File> g : byQuick.values()) {
                    if (g.size() < 2) continue;
                    if (g.get(0).length() <= 256 * 1024) { groups.add(g); continue; }
                    Map<String, List<File>> byFull = new HashMap<>();
                    for (File f : g) { if (c.get()) break; String h = fullHash(f, c); if (h == null) continue; List<File> x = byFull.get(h); if (x == null) byFull.put(h, x = new ArrayList<>()); x.add(f); }
                    for (List<File> x : byFull.values()) if (x.size() > 1) groups.add(x);
                }
                doneW += l.size();
                if (System.currentTimeMillis() - last > 350) { last = System.currentTimeMillis(); progress(req, "hash", doneW, work); }
            }
            Collections.sort(groups, (a, b) -> Long.compare(b.get(0).length() * (b.size() - 1), a.get(0).length() * (a.size() - 1)));
            JSONObject o = ev("dups", req);
            try {
                JSONArray ga = new JSONArray();
                for (int i = 0; i < Math.min(600, groups.size()); i++) {
                    List<File> g = groups.get(i);
                    Collections.sort(g, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
                    JSONArray x = new JSONArray();
                    for (File f : g) x.put(frow(f));
                    ga.put(x);
                }
                o.put("state", c.get() ? "cancelled" : "done"); o.put("groups", ga); o.put("scanned", scanned);
            } catch (Exception ignored) { }
            cancels.remove(req);
            host.emit(o);
        });
    }

    void progress(String req, String phase, long done, long total) {
        JSONObject o = ev("dups", req);
        try { o.put("state", "progress"); o.put("phase", phase); o.put("done", done); o.put("total", total); } catch (Exception ignored) { }
        host.emit(o);
    }

    static String quickHash(File f) {
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            MessageDigest md = MessageDigest.getInstance("MD5");
            long len = r.length();
            byte[] b = new byte[(int) Math.min(65536, len)];
            r.readFully(b); md.update(b);
            if (len > 131072) { r.seek(len - 65536); r.readFully(b); md.update(b); }
            return Util.hex(md.digest());
        } catch (Exception e) { return null; }
    }

    static String fullHash(File f, AtomicBoolean c) {
        try (InputStream in = new FileInputStream(f)) {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] b = new byte[1 << 18]; int n;
            while ((n = in.read(b)) > 0) { if (c.get()) return null; md.update(b, 0, n); }
            return Util.hex(md.digest());
        } catch (Exception e) { return null; }
    }

    /* ---------- categories through MediaStore ---------- */
    void category(String req, String cat) {
        exec.execute(() -> {
            JSONObject o = ev("cat", req);
            JSONArray items = new JSONArray();
            try {
                if (cat.equals("downloads")) {
                    List<File> all = new ArrayList<>();
                    ArrayDeque<File> dq = new ArrayDeque<>();
                    dq.add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS));
                    while (!dq.isEmpty() && all.size() < 5000) {
                        File[] ch = dq.poll().listFiles();
                        if (ch == null) continue;
                        for (File f : ch) { if (f.getName().startsWith(".")) continue; if (f.isDirectory()) dq.add(f); else all.add(f); }
                    }
                    Collections.sort(all, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                    for (File f : all) items.put(frow(f));
                } else {
                    Uri u = MediaStore.Files.getContentUri("external");
                    String sel; List<String> args = new ArrayList<>();
                    String[] exts = null;
                    switch (cat) {
                        case "images": sel = "media_type=1"; break;
                        case "video": sel = "media_type=3"; break;
                        case "audio": sel = "media_type=2"; break;
                        case "docs": exts = Util.DOC; sel = null; break;
                        case "archives": exts = Util.ARC; sel = null; break;
                        case "apk": exts = new String[]{"apk", "apks", "xapk"}; sel = null; break;
                        case "recent": sel = "mime_type IS NOT NULL AND date_modified>?"; args.add(String.valueOf(System.currentTimeMillis() / 1000 - 30 * 86400)); break;
                        default: sel = "1=0";
                    }
                    if (exts != null) {
                        StringBuilder sb = new StringBuilder("(");
                        for (int i = 0; i < exts.length; i++) { if (i > 0) sb.append(" OR "); sb.append("_data LIKE ?"); args.add("%." + exts[i]); }
                        sel = sb.append(")").toString();
                    }
                    int limit = cat.equals("recent") ? 400 : 20000;
                    try (Cursor cur = ctx.getContentResolver().query(u, new String[]{"_data", "_size", "date_modified"}, sel, args.toArray(new String[0]), "date_modified DESC")) {
                        if (cur != null) while (cur.moveToNext() && items.length() < limit) {
                            String p = cur.getString(0);
                            if (p == null || p.contains("/.")) continue;
                            File f = new File(p);
                            if (!f.isFile()) continue;
                            items.put(new JSONArray().put(p).put(0).put(f.length()).put(f.lastModified()));
                        }
                    }
                }
            } catch (Exception e) { try { o.put("error", e.getMessage()); } catch (Exception ignored) { } }
            try { o.put("cat", cat); o.put("items", items); } catch (Exception ignored) { }
            host.emit(o);
        });
    }
}
