package app.neonexplorer;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.pdf.PdfRenderer;
import android.media.ThumbnailUtils;
import android.os.ParcelFileDescriptor;
import android.util.LruCache;
import android.util.Size;
import android.webkit.WebResourceResponse;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

/** Thumbnails (images, video, audio covers, APK icons, PDF first page) and PDF page rendering. */
class Thumbs {
    final Context ctx;
    final LruCache<String, byte[]> mem = new LruCache<String, byte[]>(40 * 1024 * 1024) {
        @Override protected int sizeOf(String k, byte[] v) { return v.length; }
    };
    final Semaphore sem = new Semaphore(3);
    final LinkedHashMap<String, Object[]> pdfs = new LinkedHashMap<>(4, 0.75f, true);

    Thumbs(Context c) { ctx = c; }

    File dir() { File d = new File(ctx.getCacheDir(), "th"); d.mkdirs(); return d; }

    void clear() {
        mem.evictAll();
        File[] fs = dir().listFiles();
        if (fs != null) for (File f : fs) f.delete();
    }

    /** keep the disk cache under ~250 MB */
    void trim() {
        File[] fs = dir().listFiles();
        if (fs == null) return;
        long total = 0;
        for (File f : fs) total += f.length();
        if (total < 250L * 1024 * 1024) return;
        java.util.Arrays.sort(fs, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
        for (File f : fs) { if (total < 150L * 1024 * 1024) break; total -= f.length(); f.delete(); }
    }

    static byte[] encode(Bitmap bm) {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        if (bm.hasAlpha()) bm.compress(Bitmap.CompressFormat.PNG, 100, bo);
        else bm.compress(Bitmap.CompressFormat.JPEG, 82, bo);
        return bo.toByteArray();
    }

    static String sniff(byte[] b) { return b.length > 4 && (b[0] & 0xff) == 0x89 && b[1] == 'P' ? "image/png" : "image/jpeg"; }

    WebResourceResponse thumb(File f, int px) throws Exception {
        String key = Util.sha1(f.getAbsolutePath() + "|" + f.length() + "|" + f.lastModified() + "|" + px);
        byte[] b = mem.get(key);
        if (b == null) {
            File cf = new File(dir(), key);
            if (cf.exists()) {
                try (FileInputStream in = new FileInputStream(cf)) { ByteArrayOutputStream bo = new ByteArrayOutputStream(); Util.copy(in, bo); b = bo.toByteArray(); }
            } else {
                Bitmap bm = make(f, px);
                if (bm == null) return Util.notFound();
                b = encode(bm);
                bm.recycle();
                try (FileOutputStream o = new FileOutputStream(cf)) { o.write(b); } catch (IOException ignored) { }
            }
            mem.put(key, b);
        }
        return Util.bytes(sniff(b), b, true);
    }

    Bitmap make(File f, int px) throws Exception {
        String cat = Util.cat(f.getName()), e = Util.ext(f.getName());
        Size sz = new Size(px, px);
        sem.acquire();
        try {
            if (e.equals("svg")) return null;
            if (cat.equals("images")) return ThumbnailUtils.createImageThumbnail(f, sz, null);
            if (cat.equals("video")) return ThumbnailUtils.createVideoThumbnail(f, sz, null);
            if (cat.equals("audio")) { try { return ThumbnailUtils.createAudioThumbnail(f, sz, null); } catch (IOException noArt) { return null; } }
            if (e.equals("apk")) return apkIcon(f, px);
            if (e.equals("pdf")) return pdfPage(f, 0, px);
            return null;
        } finally { sem.release(); }
    }

    static Bitmap fromDrawable(Drawable d, int px) {
        if (d == null) return null;
        Bitmap bm = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        d.setBounds(0, 0, px, px);
        d.draw(c);
        return bm;
    }

    Bitmap apkIcon(File f, int px) {
        PackageManager pm = ctx.getPackageManager();
        PackageInfo pi = pm.getPackageArchiveInfo(f.getAbsolutePath(), 0);
        if (pi == null || pi.applicationInfo == null) return null;
        pi.applicationInfo.sourceDir = f.getAbsolutePath();
        pi.applicationInfo.publicSourceDir = f.getAbsolutePath();
        return fromDrawable(pi.applicationInfo.loadIcon(pm), Math.min(px, 192));
    }

    WebResourceResponse appIcon(String pkg) throws Exception {
        String key = "app:" + pkg;
        byte[] b = mem.get(key);
        if (b == null) {
            Bitmap bm = fromDrawable(ctx.getPackageManager().getApplicationIcon(pkg), 144);
            if (bm == null) return Util.notFound();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.PNG, 100, bo);
            b = bo.toByteArray();
            bm.recycle();
            mem.put(key, b);
        }
        return Util.bytes("image/png", b, false);
    }

    /* ---------- PDF ---------- */
    PdfRenderer renderer(File f) throws IOException {
        synchronized (pdfs) {
            String k = f.getAbsolutePath() + "|" + f.lastModified();
            Object[] r = pdfs.get(k);
            if (r != null) return (PdfRenderer) r[0];
            ParcelFileDescriptor pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
            PdfRenderer pr;
            try { pr = new PdfRenderer(pfd); } catch (IOException | SecurityException e) { pfd.close(); throw new IOException("PDF защищён паролем или повреждён"); }
            pdfs.put(k, new Object[]{pr, pfd});
            while (pdfs.size() > 3) {
                Iterator<Map.Entry<String, Object[]>> it = pdfs.entrySet().iterator();
                Map.Entry<String, Object[]> old = it.next();
                it.remove();
                PdfRenderer or = (PdfRenderer) old.getValue()[0];
                synchronized (or) { try { or.close(); ((ParcelFileDescriptor) old.getValue()[1]).close(); } catch (Exception ignored) { } }
            }
            return pr;
        }
    }

    Bitmap pdfPage(File f, int i, int w) throws IOException {
        PdfRenderer r = renderer(f);
        synchronized (r) {
            if (i < 0 || i >= r.getPageCount()) return null;
            PdfRenderer.Page p = r.openPage(i);
            try {
                int pw = Math.max(1, p.getWidth()), ph = Math.max(1, p.getHeight());
                w = Math.max(64, Math.min(w, 2600));
                int hh = Math.max(1, Math.round((float) w * ph / pw));
                if ((long) w * hh > 9_000_000L) { float k = (float) Math.sqrt(9_000_000.0 / ((long) w * hh)); w = Math.round(w * k); hh = Math.round(hh * k); }
                Bitmap bm = Bitmap.createBitmap(w, hh, Bitmap.Config.ARGB_8888);
                bm.eraseColor(Color.WHITE);
                p.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                return bm;
            } finally { p.close(); }
        }
    }

    WebResourceResponse pdf(File f, int i, int w) throws Exception {
        Bitmap bm = pdfPage(f, i, w);
        if (bm == null) return Util.notFound();
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 88, bo);
        bm.recycle();
        return Util.bytes("image/jpeg", bo.toByteArray(), false);
    }

    String pdfInfo(File f) {
        JSONObject o = new JSONObject();
        try {
            PdfRenderer r = renderer(f);
            synchronized (r) {
                o.put("pages", r.getPageCount());
                if (r.getPageCount() > 0) { PdfRenderer.Page p = r.openPage(0); o.put("w", p.getWidth()); o.put("h", p.getHeight()); p.close(); }
            }
        } catch (Exception e) { try { o.put("error", e.getMessage()); } catch (Exception ignored) { } }
        return o.toString();
    }
}
