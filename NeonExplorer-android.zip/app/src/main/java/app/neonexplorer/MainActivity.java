package app.neonexplorer;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.drawable.Icon;
import android.hardware.biometrics.BiometricPrompt;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.Settings;
import android.util.Base64;
import android.util.Size;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class MainActivity extends Activity implements Ops.Host, Scan.Host, WebShare.Host {
    static final String HOST = "appassets.androidplatform.net";
    static final String START = "https://" + HOST + "/assets/www/index.html";
    static final int REQ_PERM = 1;
    static final int BG = Color.parseColor("#08090f");

    WebView web;
    WebViewAssetLoader loader;
    final Handler ui = new Handler(Looper.getMainLooper());
    final ExecutorService io = Executors.newFixedThreadPool(3);
    Ops ops;
    Scan scan;
    Thumbs thumbs;
    WebShare share;
    volatile boolean vaultUnlocked = false, skipLock = false;
    volatile String pendingOpen;
    boolean picker;
    String pickMime = "*/*";
    boolean pickMultiple;
    File vaultCanon;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(BG);
        w.setNavigationBarColor(BG);
        ops = new Ops(this);
        scan = new Scan(this, this);
        thumbs = new Thumbs(this);
        share = new WebShare(this);
        try { vaultCanon = vaultDir().getCanonicalFile(); } catch (IOException e) { vaultCanon = vaultDir(); }
        Intent in = getIntent();
        picker = in != null && (Intent.ACTION_GET_CONTENT.equals(in.getAction()) || Intent.ACTION_PICK.equals(in.getAction()));
        if (picker) {
            pickMime = in.getType() == null ? "*/*" : in.getType();
            pickMultiple = in.getBooleanExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
        }
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        web = new WebView(this);
        web.setBackgroundColor(BG);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        loader = new WebViewAssetLoader.Builder().setDomain(HOST).addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String p = u.getPath();
                try {
                    if (p.equals("/thumb")) { File f = new File(u.getQueryParameter("p")); if (!allowed(f)) return Util.notFound(); return thumbs.thumb(f, num(u.getQueryParameter("s"), 256)); }
                    if (p.equals("/file")) return serveFile(new File(u.getQueryParameter("p")), req);
                    if (p.equals("/zipentry")) return zipEntry(new File(u.getQueryParameter("p")), u.getQueryParameter("e"));
                    if (p.equals("/pdf")) { File f = new File(u.getQueryParameter("p")); if (!allowed(f)) return Util.notFound(); return thumbs.pdf(f, num(u.getQueryParameter("i"), 0), num(u.getQueryParameter("w"), 1000)); }
                    if (p.equals("/appicon")) return thumbs.appIcon(u.getQueryParameter("pkg"));
                } catch (Throwable e) { return Util.notFound(); }
                return loader.shouldInterceptRequest(u);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { skipLock = true; startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.setOnLongClickListener(v -> true);
        web.setLongClickable(false);
        web.setHapticFeedbackEnabled(false);
        web.addJavascriptInterface(new Bridge(), "F");
        web.loadUrl(START);
        handleIntent(in);
        io.execute(() -> { purgeOldTrash(); thumbs.trim(); });
    }

    static int num(String s, int d) { try { return s == null ? d : Integer.parseInt(s); } catch (Exception e) { return d; } }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    void handleIntent(Intent i) {
        if (i == null) return;
        String p = i.getStringExtra("open_path");
        if (p != null) {
            pendingOpen = p;
            JSONObject o = ev("open_path");
            try { o.put("path", p); } catch (Exception ignored) { }
            emit(o);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (skipLock) { skipLock = false; return; }
        if (vaultUnlocked && prefs().getBoolean("autolock", true)) { vaultUnlocked = false; emit(ev("vault_locked")); }
    }

    @Override
    protected void onResume() {
        super.onResume();
        skipLock = false;
        if (web != null) emit(ev("resume"));
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__fBack && window.__fBack()) ? 1 : 0", r -> { if (!"1".equals(r)) { if (picker) setResult(RESULT_CANCELED); finish(); } });
    }

    @Override
    protected void onDestroy() {
        share.stop();
        io.shutdownNow();
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    /* ================= host plumbing ================= */
    SharedPreferences prefs() { return getSharedPreferences("explorer", MODE_PRIVATE); }

    static JSONObject ev(String type) { JSONObject o = new JSONObject(); try { o.put("type", type); } catch (Exception ignored) { } return o; }

    @Override
    public void emit(JSONObject o) {
        final String js = "window.__fEvent && window.__fEvent(" + JSONObject.quote(o.toString()) + ")";
        ui.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    void toast(String t) { ui.post(() -> Toast.makeText(this, t, Toast.LENGTH_LONG).show()); }

    File vaultDir() { File d = new File(getFilesDir(), "vault"); d.mkdirs(); return d; }

    @Override
    public boolean allowed(File f) {
        if (vaultUnlocked) return true;
        try { return !Util.isInside(f.getCanonicalFile(), vaultCanon); } catch (IOException e) { return !Util.isInside(f, vaultCanon); }
    }

    List<JSONObject> rootInfo() {
        List<JSONObject> out = new ArrayList<>();
        List<String> seen = new ArrayList<>();
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                StorageManager sm = getSystemService(StorageManager.class);
                for (StorageVolume v : sm.getStorageVolumes()) {
                    File d = v.getDirectory();
                    String st = v.getState();
                    if (d == null || !(Environment.MEDIA_MOUNTED.equals(st) || Environment.MEDIA_MOUNTED_READ_ONLY.equals(st))) continue;
                    addRoot(out, seen, d, v.isPrimary() ? "Внутренняя память" : v.getDescription(this), v.isPrimary(), v.isRemovable());
                }
            }
        } catch (Exception ignored) { }
        File primary = Environment.getExternalStorageDirectory();
        addRoot(out, seen, primary, "Внутренняя память", true, false);
        try {
            for (File d : getExternalFilesDirs(null)) {
                if (d == null) continue;
                String p = d.getAbsolutePath();
                int i = p.indexOf("/Android/data/");
                if (i <= 0) continue;
                File r = new File(p.substring(0, i));
                addRoot(out, seen, r, "SD-карта", false, true);
            }
        } catch (Exception ignored) { }
        return out;
    }

    void addRoot(List<JSONObject> out, List<String> seen, File d, String name, boolean primary, boolean removable) {
        String p = d.getAbsolutePath();
        if (seen.contains(p)) return;
        seen.add(p);
        try {
            JSONObject o = new JSONObject();
            o.put("path", p); o.put("name", name); o.put("primary", primary); o.put("removable", removable);
            StatFs s = new StatFs(p);
            o.put("total", s.getTotalBytes()); o.put("free", s.getAvailableBytes());
            out.add(o);
        } catch (Exception ignored) { }
    }

    @Override
    public List<File> roots() {
        List<File> l = new ArrayList<>();
        for (JSONObject o : rootInfo()) l.add(new File(o.optString("path")));
        return l;
    }

    @Override
    public File volumeRoot(File f) {
        File best = null;
        for (File r : roots()) if (Util.isInside(f, r) && (best == null || r.getAbsolutePath().length() > best.getAbsolutePath().length())) best = r;
        return best;
    }

    @Override
    public void scan(List<String> paths) {
        for (int i = 0; i < paths.size(); i += 300) {
            List<String> part = paths.subList(i, Math.min(paths.size(), i + 300));
            try { MediaScannerConnection.scanFile(this, part.toArray(new String[0]), null, null); } catch (Exception ignored) { }
        }
    }

    String permState() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager() ? "full" : "none";
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED ? "full" : "none";
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        JSONObject o = ev("perm");
        try { o.put("state", permState()); } catch (Exception ignored) { }
        emit(o);
    }

    WebResourceResponse serveFile(File f, WebResourceRequest req) throws Exception {
        if (!allowed(f) || !f.isFile()) return Util.notFound();
        String e = Util.ext(f.getName());
        if (e.equals("heic") || e.equals("heif")) {
            Bitmap bm = ImageDecoder.decodeBitmap(ImageDecoder.createSource(f), (dec, info, src) -> {
                Size sz = info.getSize();
                int max = Math.max(sz.getWidth(), sz.getHeight());
                if (max > 4096) { float k = 4096f / max; dec.setTargetSize(Math.round(sz.getWidth() * k), Math.round(sz.getHeight() * k)); }
            });
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 92, bo);
            bm.recycle();
            return Util.bytes("image/jpeg", bo.toByteArray(), false);
        }
        final File ff = f;
        return Util.ranged(() -> new FileInputStream(ff), f.length(), Util.mime(f.getName()), req.getRequestHeaders());
    }

    WebResourceResponse zipEntry(File f, String name) throws Exception {
        if (!allowed(f)) return Util.notFound();
        final ZipFile z = Ops.openZip(f);
        ZipEntry e = z.getEntry(name);
        if (e == null) { z.close(); return Util.notFound(); }
        final InputStream in = z.getInputStream(e);
        InputStream wrapped = new java.io.FilterInputStream(in) { @Override public void close() throws IOException { super.close(); z.close(); } };
        return new WebResourceResponse(Util.mime(name), null, 200, "OK", new java.util.HashMap<>(), wrapped);
    }

    void purgeOldTrash() {
        long limit = System.currentTimeMillis() - 30L * 86400000L;
        for (File r : roots()) {
            File td = new File(r, Ops.TRASH);
            if (!td.isDirectory()) continue;
            synchronized (Ops.class) {
                JSONObject idx = Ops.loadIndex(td);
                boolean changed = false;
                File[] fs = td.listFiles();
                if (fs != null) for (File f : fs) {
                    String n = f.getName();
                    if (n.startsWith(".")) continue;
                    JSONObject e = idx.optJSONObject(n);
                    long t = e != null ? e.optLong("t", f.lastModified()) : f.lastModified();
                    if (t < limit) { Util.deleteTree(f); idx.remove(n); changed = true; }
                }
                if (changed) Ops.saveIndex(td, idx);
            }
        }
    }

    Uri uriFor(File f) { return FileProvider.getUriForFile(this, getPackageName() + ".files", f); }

    static String hashPin(String pin, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pin.toCharArray(), salt, 20000, 256);
        return Base64.encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(), Base64.NO_WRAP);
    }

    String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) { ByteArrayOutputStream bo = new ByteArrayOutputStream(); Util.copy(in, bo); return bo.toString("UTF-8"); }
        catch (IOException e) { return "<h1>Neon Explorer</h1>"; }
    }

    void startExt(Intent i, String title) {
        ui.post(() -> {
            try { skipLock = true; startActivity(title == null ? i : Intent.createChooser(i, title)); }
            catch (Exception e) { skipLock = false; toast("Нет подходящего приложения"); }
        });
    }

    /* ================= JavaScript bridge ================= */
    class Bridge {
        @JavascriptInterface public int sdk() { return Build.VERSION.SDK_INT; }

        @JavascriptInterface public String perm() { return permState(); }

        @JavascriptInterface
        public void requestPerm() {
            ui.post(() -> {
                if (Build.VERSION.SDK_INT >= 30) {
                    try { skipLock = true; startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName()))); }
                    catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); } catch (Exception ignored) { } }
                } else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_PERM);
            });
        }

        @JavascriptInterface
        public void openAppSettings() { startExt(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())), null); }

        @JavascriptInterface
        public String roots() { JSONArray a = new JSONArray(); for (JSONObject o : rootInfo()) a.put(o); return a.toString(); }

        @JavascriptInterface public String home() { return Environment.getExternalStorageDirectory().getAbsolutePath(); }

        @JavascriptInterface public String downloads() { return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath(); }

        @JavascriptInterface
        public void list(String req, String path) {
            io.execute(() -> {
                JSONObject o = ev("list");
                try {
                    o.put("req", req); o.put("path", path);
                    File d = new File(path);
                    if (!allowed(d)) throw new IOException("Сейф заблокирован");
                    File[] ch = d.listFiles();
                    if (ch == null) throw new IOException(!d.exists() ? "Папка не найдена" : "none".equals(permState()) ? "Нет разрешения на доступ к файлам" : "Нет доступа к этой папке (Android запрещает открывать её)");
                    JSONArray items = new JSONArray();
                    boolean counts = ch.length <= 4000;
                    for (File f : ch) items.put(Util.row(f, counts));
                    o.put("items", items); o.put("writable", d.canWrite());
                } catch (Exception e) { try { o.put("error", e.getMessage()); } catch (Exception ignored) { } }
                emit(o);
            });
        }

        @JavascriptInterface
        public String stat(String path) {
            JSONObject o = new JSONObject();
            try {
                File f = new File(path);
                o.put("exists", f.exists() && allowed(f));
                if (f.exists() && allowed(f)) {
                    o.put("dir", f.isDirectory()); o.put("size", f.isDirectory() ? 0 : f.length()); o.put("t", f.lastModified());
                    o.put("r", f.canRead()); o.put("w", f.canWrite()); o.put("hidden", f.getName().startsWith(".")); o.put("link", Util.isSymlink(f));
                    o.put("parent", f.getParent() == null ? "" : f.getParent());
                    o.put("canonical", f.getCanonicalPath());
                }
            } catch (Exception ignored) { }
            return o.toString();
        }

        @JavascriptInterface
        public String mkdir(String parent, String name) {
            File p = new File(parent);
            if (!allowed(p)) return "Нет доступа";
            File d = new File(p, Util.safeName(name));
            if (d.exists()) return "Такое имя уже есть";
            return d.mkdirs() ? "" : "Не удалось создать папку";
        }

        @JavascriptInterface
        public String newFile(String parent, String name) {
            File p = new File(parent);
            if (!allowed(p)) return "Нет доступа";
            File f = new File(p, Util.safeName(name));
            if (f.exists()) return "Такое имя уже есть";
            try { return f.createNewFile() ? "" : "Не удалось создать файл"; } catch (IOException e) { return e.getMessage(); }
        }

        @JavascriptInterface
        public String rename(String path, String newName) {
            File f = new File(path);
            if (!allowed(f)) return "Нет доступа";
            String n = Util.safeName(newName);
            File t = new File(f.getParentFile(), n);
            if (t.getAbsolutePath().equals(f.getAbsolutePath())) return "";
            if (t.exists() && !t.getName().equalsIgnoreCase(f.getName())) return "Такое имя уже есть";
            boolean ok;
            if (t.getName().equalsIgnoreCase(f.getName())) {
                File tmp = new File(f.getParentFile(), "." + n + ".rn" + System.nanoTime());
                ok = f.renameTo(tmp) && tmp.renameTo(t);
            } else ok = f.renameTo(t);
            if (!ok) return "Не удалось переименовать";
            List<String> sc = new ArrayList<>();
            if (t.isFile()) { sc.add(f.getAbsolutePath()); sc.add(t.getAbsolutePath()); }
            if (!sc.isEmpty()) scan(sc);
            return "";
        }

        @JavascriptInterface public void op(String json) { ops.start(json); }

        @JavascriptInterface public void opAnswer(String id, String choice, boolean all) { ops.answer(id, choice, all); }

        @JavascriptInterface public void opCancel(String id) { ops.cancel(id); }

        @JavascriptInterface public void dirSize(String req, String path) { scan.dirSize(req, path); }

        @JavascriptInterface public void hash(String req, String path, String algo) { scan.hash(req, path, algo); }

        @JavascriptInterface public void search(String req, String root, String q, String filters) { scan.search(req, root, q, filters); }

        @JavascriptInterface public void cancelTask(String req) { scan.cancel(req); }

        @JavascriptInterface public void analyze(String req, String root) { scan.analyze(req, root); }

        @JavascriptInterface public String analyzeDir(String path) { return scan.analyzeDir(path); }

        @JavascriptInterface public void dups(String req, String root, long minSize) { scan.dups(req, root, minSize); }

        @JavascriptInterface public void category(String req, String cat) { scan.category(req, cat); }

        @JavascriptInterface
        public String writeText(String path, String text) {
            File f = new File(path);
            if (!allowed(f)) return "Нет доступа";
            File tmp = new File(f.getParentFile(), "." + f.getName() + ".tmp" + System.nanoTime());
            try (OutputStream o = new FileOutputStream(tmp)) { o.write(text.getBytes(StandardCharsets.UTF_8)); }
            catch (IOException e) { tmp.delete(); return "Не удалось сохранить: " + e.getMessage(); }
            if (!tmp.renameTo(f)) { if (!f.delete() || !tmp.renameTo(f)) { tmp.delete(); return "Не удалось сохранить файл"; } }
            List<String> sc = new ArrayList<>(); sc.add(f.getAbsolutePath()); scan(sc);
            return "";
        }

        @JavascriptInterface
        public String zipList(String path) {
            JSONObject o = new JSONObject();
            File f = new File(path);
            try (ZipFile z = Ops.openZip(f)) {
                if (!allowed(f)) throw new IOException("Нет доступа");
                JSONArray a = new JSONArray();
                Enumeration<? extends ZipEntry> en = z.entries();
                int n = 0;
                while (en.hasMoreElements() && n < 50000) { ZipEntry e = en.nextElement(); a.put(new JSONArray().put(e.getName()).put(e.isDirectory() ? 1 : 0).put(e.getSize()).put(e.getCompressedSize()).put(e.getTime())); n++; }
                o.put("entries", a);
            } catch (Exception e) { try { o.put("error", e.getMessage() == null ? "Не удалось открыть архив" : e.getMessage()); } catch (Exception ignored) { } }
            return o.toString();
        }

        @JavascriptInterface
        public String apkInfo(String path) {
            JSONObject o = new JSONObject();
            try {
                PackageManager pm = getPackageManager();
                PackageInfo pi = pm.getPackageArchiveInfo(path, PackageManager.GET_PERMISSIONS);
                if (pi == null || pi.applicationInfo == null) throw new Exception("Файл повреждён или это не APK");
                pi.applicationInfo.sourceDir = path; pi.applicationInfo.publicSourceDir = path;
                o.put("label", String.valueOf(pi.applicationInfo.loadLabel(pm)));
                o.put("pkg", pi.packageName); o.put("version", pi.versionName == null ? "" : pi.versionName); o.put("code", pi.getLongVersionCode());
                o.put("minSdk", pi.applicationInfo.minSdkVersion); o.put("targetSdk", pi.applicationInfo.targetSdkVersion);
                o.put("perms", pi.requestedPermissions == null ? 0 : pi.requestedPermissions.length);
                try { PackageInfo cur = pm.getPackageInfo(pi.packageName, 0); o.put("installed", cur.versionName == null ? "" : cur.versionName); o.put("installedCode", cur.getLongVersionCode()); } catch (PackageManager.NameNotFoundException ignored) { }
            } catch (Exception e) { try { o.put("error", e.getMessage()); } catch (Exception ignored) { } }
            return o.toString();
        }

        @JavascriptInterface
        public void installApk(String path) {
            if (!getPackageManager().canRequestPackageInstalls()) {
                toast("Разрешите Neon Explorer устанавливать приложения и нажмите «Установить» ещё раз");
                startExt(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())), null);
                return;
            }
            try {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(uriFor(new File(path)), "application/vnd.android.package-archive");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                startExt(i, null);
            } catch (Exception e) { toast("Не удалось начать установку"); }
        }

        @JavascriptInterface
        public void openWith(String path, String mime) {
            try {
                File f = new File(path);
                if (!allowed(f)) return;
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(uriFor(f), mime == null || mime.isEmpty() ? Util.mime(f.getName()) : mime);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                startExt(i, "Открыть с помощью");
            } catch (Exception e) { toast("Нельзя открыть этот файл"); }
        }

        @JavascriptInterface
        public void share(String pathsJson) {
            try {
                JSONArray a = new JSONArray(pathsJson);
                ArrayList<Uri> uris = new ArrayList<>();
                String mime = null;
                for (int k = 0; k < a.length(); k++) {
                    File f = new File(a.getString(k));
                    if (!f.isFile() || !allowed(f)) continue;
                    uris.add(uriFor(f));
                    String m = Util.mime(f.getName());
                    mime = mime == null ? m : mime.equals(m) ? m : mime.split("/")[0].equals(m.split("/")[0]) ? mime.split("/")[0] + "/*" : "*/*";
                }
                if (uris.isEmpty()) { toast("Папки нельзя отправить — сожмите их в ZIP"); return; }
                Intent i;
                if (uris.size() == 1) { i = new Intent(Intent.ACTION_SEND); i.putExtra(Intent.EXTRA_STREAM, uris.get(0)); }
                else { i = new Intent(Intent.ACTION_SEND_MULTIPLE); i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris); }
                i.setType(mime);
                ClipData cd = ClipData.newRawUri("", uris.get(0));
                for (int k = 1; k < uris.size(); k++) cd.addItem(new ClipData.Item(uris.get(k)));
                i.setClipData(cd);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startExt(i, "Отправить");
            } catch (Exception e) { toast("Не удалось поделиться"); }
        }

        @JavascriptInterface
        public void copyText(String text) {
            ui.post(() -> {
                ClipboardManager cm = getSystemService(ClipboardManager.class);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("text", text));
            });
        }

        @JavascriptInterface public void toast(String t) { MainActivity.this.toast(t); }

        /* ---- apps ---- */
        @JavascriptInterface
        public void apps(String req, boolean system) {
            io.execute(() -> {
                JSONObject o = ev("apps");
                JSONArray a = new JSONArray();
                try {
                    PackageManager pm = getPackageManager();
                    for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
                        boolean sys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                        if (sys && !system) continue;
                        long size = new File(ai.sourceDir).length();
                        if (ai.splitSourceDirs != null) for (String sp : ai.splitSourceDirs) size += new File(sp).length();
                        String ver = "";
                        long first = 0, upd = 0;
                        try { PackageInfo pi = pm.getPackageInfo(ai.packageName, 0); ver = pi.versionName == null ? "" : pi.versionName; first = pi.firstInstallTime; upd = pi.lastUpdateTime; } catch (Exception ignored) { }
                        a.put(new JSONArray().put(ai.packageName).put(String.valueOf(ai.loadLabel(pm))).put(ver).put(size).put(first).put(upd).put(sys ? 1 : 0).put(ai.enabled ? 1 : 0)
                                .put(pm.getLaunchIntentForPackage(ai.packageName) != null ? 1 : 0).put(ai.splitSourceDirs == null ? 0 : ai.splitSourceDirs.length));
                    }
                    o.put("req", req); o.put("items", a);
                } catch (Exception e) { try { o.put("error", e.getMessage()); } catch (Exception ignored) { } }
                emit(o);
            });
        }

        @JavascriptInterface
        public String appSource(String pkg) {
            JSONObject o = new JSONObject();
            try {
                PackageManager pm = getPackageManager();
                ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                PackageInfo pi = pm.getPackageInfo(pkg, 0);
                o.put("src", ai.sourceDir); o.put("label", String.valueOf(ai.loadLabel(pm))); o.put("version", pi.versionName == null ? "" : pi.versionName);
                o.put("splits", ai.splitSourceDirs == null ? 0 : ai.splitSourceDirs.length);
            } catch (Exception e) { try { o.put("error", e.getMessage()); } catch (Exception ignored) { } }
            return o.toString();
        }

        @JavascriptInterface
        public void appAction(String pkg, String action) {
            try {
                Intent i = null;
                if ("open".equals(action)) i = getPackageManager().getLaunchIntentForPackage(pkg);
                else if ("info".equals(action)) i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
                else if ("uninstall".equals(action)) i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg));
                else if ("store".equals(action)) i = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg));
                if (i == null) { toast("Это приложение нельзя открыть"); return; }
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startExt(i, null);
            } catch (Exception e) { toast("Действие недоступно"); }
        }

        /* ---- pdf ---- */
        @JavascriptInterface public String pdfInfo(String path) { File f = new File(path); return allowed(f) ? thumbs.pdfInfo(f) : "{\"error\":\"Нет доступа\"}"; }

        /* ---- Wi-Fi access from a computer ---- */
        @JavascriptInterface
        public String serverStart(boolean upload) {
            JSONObject o = share.start(readAsset("www/pc.html"), upload);
            ui.post(() -> getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON));
            return o.toString();
        }

        @JavascriptInterface
        public void serverStop() {
            share.stop();
            ui.post(() -> getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON));
        }

        @JavascriptInterface public String serverState() { return share.state().toString(); }

        /* ---- trash ---- */
        @JavascriptInterface
        public String trashList() {
            JSONArray a = new JSONArray();
            for (File r : MainActivity.this.roots()) {
                File td = new File(r, Ops.TRASH);
                if (!td.isDirectory()) continue;
                JSONObject idx = Ops.loadIndex(td);
                File[] fs = td.listFiles();
                if (fs != null) for (File f : fs) {
                    String n = f.getName();
                    if (n.startsWith(".")) continue;
                    JSONObject e = idx.optJSONObject(n);
                    int u = n.indexOf('_');
                    a.put(new JSONArray().put(f.getAbsolutePath())
                            .put(e != null ? e.optString("o") : r.getAbsolutePath() + "/" + (u > 0 ? n.substring(u + 1) : n))
                            .put(e != null ? e.optLong("t") : f.lastModified())
                            .put(e != null ? e.optLong("s") : f.length())
                            .put(f.isDirectory() ? 1 : 0)
                            .put(e != null ? e.optLong("n", 1) : 1));
                }
            }
            return a.toString();
        }

        /* ---- vault ---- */
        @JavascriptInterface public String vaultPath() { return vaultDir().getAbsolutePath(); }

        @JavascriptInterface public boolean vaultHasPin() { return prefs().contains("pin_hash"); }

        @JavascriptInterface public boolean vaultIsUnlocked() { return vaultUnlocked; }

        @JavascriptInterface
        public boolean vaultSetPin(String pin) {
            if (vaultHasPin() && !vaultUnlocked) return false;
            if (pin == null || pin.length() < 4) return false;
            try {
                byte[] salt = new byte[16];
                new SecureRandom().nextBytes(salt);
                prefs().edit().putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP)).putString("pin_hash", hashPin(pin, salt)).apply();
                vaultUnlocked = true;
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public boolean vaultUnlock(String pin) {
            try {
                if (System.currentTimeMillis() < prefs().getLong("lock_until", 0)) return false;
                byte[] salt = Base64.decode(prefs().getString("pin_salt", ""), Base64.NO_WRAP);
                boolean ok = MessageDigest.isEqual(hashPin(pin, salt).getBytes(), prefs().getString("pin_hash", "").getBytes());
                int fails = ok ? 0 : prefs().getInt("fails", 0) + 1;
                SharedPreferences.Editor e = prefs().edit().putInt("fails", fails);
                if (fails >= 5) e.putLong("lock_until", System.currentTimeMillis() + 30000L * (fails - 4));
                e.apply();
                vaultUnlocked = ok;
                return ok;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public long vaultLockedFor() { return Math.max(0, prefs().getLong("lock_until", 0) - System.currentTimeMillis()); }

        @JavascriptInterface public void vaultLock() { vaultUnlocked = false; }

        @JavascriptInterface public void setPref(String k, boolean v) { prefs().edit().putBoolean(k, v).apply(); }

        @JavascriptInterface
        public void vaultBiometric() {
            ui.post(() -> {
                try {
                    BiometricPrompt bp = new BiometricPrompt.Builder(MainActivity.this)
                            .setTitle("Сейф Neon Explorer")
                            .setSubtitle("Подтвердите, что это вы")
                            .setNegativeButton("Ввести PIN", getMainExecutor(), (d, w) -> emit(bio(false, "cancel")))
                            .build();
                    bp.authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                        @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) { vaultUnlocked = true; emit(bio(true, null)); }
                        @Override public void onAuthenticationError(int code, CharSequence msg) { emit(bio(false, String.valueOf(msg))); }
                    });
                } catch (Exception e) { emit(bio(false, "Биометрия недоступна")); }
            });
        }

        JSONObject bio(boolean ok, String msg) { JSONObject o = ev("bio"); try { o.put("ok", ok); if (msg != null) o.put("msg", msg); } catch (Exception ignored) { } return o; }

        @JavascriptInterface
        public void setSecure(boolean on) {
            ui.post(() -> { if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE); else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE); });
        }

        /* ---- file picker for other apps ---- */
        @JavascriptInterface
        public String pickMode() {
            if (!picker) return "";
            JSONObject o = new JSONObject();
            try { o.put("mime", pickMime); o.put("multiple", pickMultiple); } catch (Exception ignored) { }
            return o.toString();
        }

        @JavascriptInterface
        public void pickDone(String pathsJson) {
            ui.post(() -> {
                try {
                    JSONArray a = new JSONArray(pathsJson);
                    if (a.length() == 0) return;
                    Intent r = new Intent();
                    Uri first = uriFor(new File(a.getString(0)));
                    r.setData(first);
                    ClipData cd = ClipData.newRawUri("", first);
                    for (int k = 1; k < a.length(); k++) cd.addItem(new ClipData.Item(uriFor(new File(a.getString(k)))));
                    r.setClipData(cd);
                    r.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    setResult(RESULT_OK, r);
                    finish();
                } catch (Exception e) { toast("Не удалось передать файл"); }
            });
        }

        @JavascriptInterface public void pickCancel() { ui.post(() -> { setResult(RESULT_CANCELED); finish(); }); }

        /* ---- misc ---- */
        @JavascriptInterface
        public String takeOpen() { String p = pendingOpen; pendingOpen = null; return p == null ? "" : p; }

        @JavascriptInterface
        public boolean pinShortcut(String path, String label) {
            try {
                ShortcutManager sm = getSystemService(ShortcutManager.class);
                if (sm == null || !sm.isRequestPinShortcutSupported()) return false;
                Intent i = new Intent(MainActivity.this, MainActivity.class).setAction(Intent.ACTION_VIEW).putExtra("open_path", path).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                ShortcutInfo si = new ShortcutInfo.Builder(MainActivity.this, "dir" + Integer.toHexString(path.hashCode()))
                        .setShortLabel(label.length() > 24 ? label.substring(0, 24) : label)
                        .setIcon(Icon.createWithResource(MainActivity.this, getApplicationInfo().icon))
                        .setIntent(i).build();
                return sm.requestPinShortcut(si, null);
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public void clearCache() { thumbs.clear(); }

        @JavascriptInterface
        public String audioMeta(String path) {
            JSONObject o = new JSONObject();
            android.media.MediaMetadataRetriever r = new android.media.MediaMetadataRetriever();
            try {
                File f = new File(path);
                if (!allowed(f)) return "{}";
                r.setDataSource(path);
                String t = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE);
                String a = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST);
                String al = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUM);
                if (t != null && !t.trim().isEmpty()) o.put("title", t.trim());
                if (a != null && !a.trim().isEmpty()) o.put("artist", a.trim());
                if (al != null && !al.trim().isEmpty()) o.put("album", al.trim());
            } catch (Exception ignored) {
            } finally { try { r.release(); } catch (Exception ignored) { } }
            return o.toString();
        }

        @JavascriptInterface
        public void scanMedia(String pathsJson) {
            try { JSONArray a = new JSONArray(pathsJson); List<String> l = new ArrayList<>(); for (int k = 0; k < a.length(); k++) l.add(a.getString(k)); scan(l); } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public String deviceInfo() {
            JSONObject o = new JSONObject();
            try { o.put("model", Build.MANUFACTURER + " " + Build.MODEL); o.put("android", Build.VERSION.RELEASE); o.put("sdk", Build.VERSION.SDK_INT); } catch (Exception ignored) { }
            return o.toString();
        }
    }
}
